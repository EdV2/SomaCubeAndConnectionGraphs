There may be some mistakes.

Expect to do some resorting and categorizing after the subgraph comparisons

No big deal.  Green Orange Yellow geode subgraph isometry is the mission here.  